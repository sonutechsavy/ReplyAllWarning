function proceed() {
  Office.context.ui.messageParent("proceed");
}

function cancel() {
  Office.context.ui.messageParent("cancel");
}